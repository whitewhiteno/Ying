# Daily UI Website

這個網站是提供給參與dailyui的設計師們，所以不需要會寫程式，可以輕易的做出自己dailyui的網站。
#DEMO
[wesleyweazin.github.io/dailyui](http://wesleyweazin.github.io/dailyui/)

##圖片更換方式
###作品圖片
找到images這個資料夾，將圖片替換成自己的作品即可。    
格式是：day1.jpg~day100.jpg。   
如果沒做的，會直接跳過那天，不會顯示。

###封面圖片
找到images這個資料夾，替換掉desktop.jpg跟mobile.jpg這兩個檔案即可。  
請注意圖片的大小與格式。

##連結更換方式
找到資料夾下的links.json，直接更改對應的連結即可。
